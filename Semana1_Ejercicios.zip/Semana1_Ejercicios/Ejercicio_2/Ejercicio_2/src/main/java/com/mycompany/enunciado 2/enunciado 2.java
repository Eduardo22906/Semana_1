/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tarea_apli_2;
import Vista.apli; /** * 

@author User 

*/ public class Tarea_apli_2 { 

public static void main(String[] args) { 
      apli ejem = new apli(); 
      ejem.show(); 
} 
 
} 
